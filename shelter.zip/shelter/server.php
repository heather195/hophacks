<!--

server.php
- Assists in connection to the database and helps streamline certain server relationships between the PHP and MySQL database, primarily the login function.

Team shelter_db (Heather Craddock, Nina Hamidli, Veena Thamilselvan)
For: HopHacks, Johns Hopkins University, Baltimore MD, 14-16 September 2018



-->

<?php
session_start();

	$username = "";
	$password = "";
	$errors = array();

	function db_connect(){ //db_connect() establishes a connection with the MySQL Database
		$db = mysqli_connect('localhost','root','root','shelter_db');
		return $db;
	}

	$db = db_connect(); //Create a connection object for connection to the database

	// IF THE LOGIN BUTTON IS PRESSED
	if (isset($_POST['user_login'])) {
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$password = mysqli_real_escape_string($db, $_POST['password']);
		$password = md5($password);
		/*gather the username and password and hash the password
		NOTE: MD5 hash is not a very secure or reliable hash for a live website, and is used purely for the pursposes of displaying the need for consideration of system security and password protection.
		*/

		if (empty($username)) {
			array_push($errors, "Username is required.");
		}
		if (empty($password)) {
			array_push($errors, "Password is required.");
		}
		if (count($errors) == 0) {
			$query = "SELECT * FROM shelter WHERE usern='$username' AND passw='$password'"; //find the user
			$results = mysqli_query($db, $query);
			if (mysqli_num_rows($results) == 1) { /*if the username and password combo is found, log in!*/
		    	$user = mysqli_fetch_assoc($results);
		    	$_SESSION['username'] = $username;
		    	$_SESSION['success'] = "Log In Successful";
		    	header('location: index.php');
			}else { 
				array_push($errors, "Username or Password incorrect");
			}
		}
	}

?>