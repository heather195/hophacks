<!--

login.php
- The login interface provides the tool for a registered staff member to use their credentials to log in to the shelter's account.

Team shelter_db (Heather Craddock, Nina Hamidli, Veena Thamilselvan)
For: HopHacks, Johns Hopkins University, Baltimore MD, 14-16 September 2018


-->

<?php include('server.php')?>

<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
  <header>
    <div id="heading">
      <ul>
          <li><a href="index.php">Homepage</a></li>
          <!-- If noone is logged in, log in option should be available -->
          <?php if (!isset($_SESSION['username'])) : ?> 
            <li><a href="login.php">Log In</a></li>
          <?php endif ?>
          <!-- If user is logged in, management and log out options should be available -->
          <?php if(isset($_SESSION['username'])) : ?>
            <li><a href="profile.php">Manage Profile</a></li>
            <li><a href="destroysession.php">Log Out</a></li>
          <?php endif ?>
      </ul>
    </div>
  </header>

<body>
  <div class="container">

    <!-- Log In Form, dealt with in server.php -->
    <form method="post" action="login.php">
      <?php include('errors.php'); ?>
      <div class="input-group">
        <label>Username</label>
        <input type="text" name="username">
      </div>
      <div class="input-group">
        <label>Password</label>
        <input type="password" name="password">
      </div>
      <div class="input-group">
        <button type="submit" class="btn" name="user_login">Login</button>
      </div>
    </form>
  </div>

  <footer>
      <p>
          Shelter_db &copy; <?php echo date("Y"); ?>
      </p>
  </footer>

</body>
</html>