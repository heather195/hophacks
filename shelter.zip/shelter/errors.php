<!--

errors.php
- Assists in error handling

Team shelter_db (Heather Craddock, Nina Hamidli, Veena Thamilselvan)
For: HopHacks, Johns Hopkins University, Baltimore MD, 14-16 September 2018


-->

<!-- If there are errors, print them -->
<?php if(count($errors) > 0) : ?>
	<div class="error">
		<?php foreach ($errors as $error) : ?>
			<p><?php echo $error ?></p>
		<?php endforeach ?>
	</div>
<?php endif ?>