<!--

index.php
- Webite Homepage, includes information regarding shelters, and bed availability. Bed availability is currently theoretical, as that data would not be available without the partnership of the local homeless-serving operations. Also present is a Google Maps API displaying the location of all the known homeless shelters in Baltimore, MD, for user convenience.

Team shelter_db (Heather Craddock, Nina Hamidli, Veena Thamilselvan)
For: HopHacks, Johns Hopkins University, Baltimore MD, 14-16 September 2018



-->

<?php include('server.php')?>

<?php
session_start(); 
$user = $_SESSION['username'];
$db = db_connect();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Shelter</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
  <header>
    <div id="heading">
      <ul>
        <!-- Menu options depending on log in status -->
          <li><a href="index.php">Homepage</a></li>
          <?php if (!isset($_SESSION['username'])) : ?>
            <li><a href="login.php">Log In</a></li>
          <?php endif ?>
          <?php if(isset($_SESSION['username'])) : ?>
            <li><a href="profile.php">Manage Profile</a></li>
            <li><a href="destroysession.php">Log Out</a></li>
          <?php endif ?>
      </ul>
    </div>
  </header>
<div class="container">

  <!-- Table to display the shelters and rooms from the database-->
  <h1>Shelter Room Availability:</h1>

  <div style="height:300px; overflow:scroll; text-align: center;">
    <?php
      $result = mysqli_query($db,"SELECT * FROM shelter");

      echo "<table border='1px solid black' width='80%' align='center'>
      <tr>
      <th>Shelter</th>
      <th>Beds Remaining</th>
      <th>Address</th>
      <th>Phone Number</th>
      <th>Website</th>
      </tr>";

      while($row = mysqli_fetch_array($result))
      {
      echo "<tr>";
      echo "<td>" . $row['shelter_name'] . " (".$row['shelter_type'].")"."</td>";
      echo "<td>" . $row['shelter_beds_left'] . "</td>";
      echo "<td>" . $row['location'] . ", " . $row['shelter_zip'] ."</td>";
      echo "<td>" . $row['shelter_phoneNum'] . "</td>";
      echo "<td>" . $row['shelter_website'] . "</td>";
      echo "</tr>";
      }
      echo "</table>";
    ?>
  </div>

  <br><br><br>

  <!-- Google API to show the location of the shelters -->
  <h1>Shelter Map:</h1>
  <iframe src="https://www.google.com/maps/d/embed?mid=1yGx9qdp0OLE9TlL9azZ9Uw4BWtkILYhE" width="640" height="480"></iframe>



</div>
  <footer>
      <p>
          Shelter_db &copy; <?php echo date("Y"); ?>
      </p>
  </footer>

</body>
</html>