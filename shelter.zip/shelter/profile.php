<!--

profile.php
- This profile.php file can only be reached by a registered user (that is, a staff member of one of the homeless shelters). Through this page, users can edit their password, and update the count of their available beds so that the homeless population in Dover have accurate and timely data.

Team shelter_db (Heather Craddock, Nina Hamidli, Veena Thamilselvan)
For: HopHacks, Johns Hopkins University, Baltimore MD, 14-16 September 2018


-->


<?php include('server.php')?>

<!-- If not logged in, access denied -->
<?php if (!isset($_SESSION['username'])){
  header("location: index.php");
} 

$user = $_SESSION['username'];
$db = db_connect();
?>

<?php
$query1 = "SELECT * FROM shelter WHERE usern='$user'";
$res1 = mysqli_query($db, $query1);
$shelter = mysqli_fetch_assoc($res1);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
  <header>
    <div id="heading">
      <ul>
        <!-- Options for logged in user (can only be logged in on this page) -->
          <?php if(isset($_SESSION['username'])) : ?>
            <li><a href="index.php">Homepage</a></li>
            <li><a href="profile.php">Manage Profile</a></li>
            <li><a href="destroysession.php">Log Out</a></li>
          <?php endif ?>
      </ul>
    </div>
  </header>

  <div class="container">
  <?php
    //php dealing with a request to change password
    if($_POST['changepw']) {
      if(empty($_POST["pw1"]) || (empty($_POST["pw2"])) || ($_POST["pw1"] != $_POST["pw2"])) {
        $pwErr = "* Current and new password required, and they must match.";
      }
      else{
        $newpwd = $_POST['pw1'];
        $newpwd = md5($newpwd);
        $sql = "UPDATE shelter SET passw = '$newpwd' WHERE usern='$user'";
        if (mysqli_query($db, $sql)) {
          echo '<p style="color:rgb(200,0,0)">Password Updated</p>';
        } else {
          echo '<p style="color:rgb(200,0,0)">Error Updating DB</p><br>';
        } 
      }

    }

    //php dealing with a request to update the # of available rooms
    if($_POST['numrooms']) {
      $input= $_POST['freerooms'];
      $sql = "UPDATE shelter SET shelter_beds_left='$input' WHERE usern='$user'";
      if (mysqli_query($db, $sql)) {
        echo '<p style="color:rgb(200,0,0)">Bed Count Updated</p>';
      } else {
        echo '<p style="color:rgb(200,0,0)">Error Updating DB</p><br>';
      }            
    }

    //php dealing with a request to increment the number of beds available
    if($_POST['incr']){
      $resulti = $shelter['shelter_beds_left'];
      $sql = "UPDATE shelter SET shelter_beds_left=('$resulti'+1) WHERE usern='$user'";
      if (mysqli_query($db, $sql)) {
        echo '<p style="color:rgb(200,0,0)">Bed Count Updated</p>';
      } else {
        echo '<p style="color:rgb(200,0,0)">Error Updating DB</p><br>';
      } 
    }

    //php dealing with a request to decrement the number of beds available
    if($_POST['decr']){
      $resultd = $shelter['shelter_beds_left'];
      $sql2 = "UPDATE shelter SET shelter_beds_left=('$resultd'-1) WHERE usern='$user'";
      if (mysqli_query($db, $sql2)) {
        echo '<p style="color:rgb(200,0,0)">Bed Count Updated</p>';
      } else {
        echo '<p style="color:rgb(200,0,0)">Error Updating DB</p><br>';
      } 
    }
  ?>
    
    <!-- Display current # of available rooms -->
    <h1 style='text-align: center'>Current Rooms Available: <b><?php echo $shelter['shelter_beds_left'] ?></b></h1><br>


<!-- PROFILE UPDATE FORMS -->
    <b>Update available rooms<br></b>
    <form method="post"> 
      How many rooms are still available?<br>
      <input type="number" name="freerooms"><br>
      <input type="submit" class = "btn" name="numrooms" value="Submit"><br><br><br>
      <input type="submit" class = "btn" name="incr" value="Person checked out"><br><br>
      <input type="submit" class = "btn" name="decr" value="Person checked in"><br>
    </form>

    <br>
    <b>Change Password <br></b>

    <form method="post"> 
      New Password<br>
      <input type="password" name="pw1"><br>
      Confirm Password<br>
      <input type="password" name="pw2">
      <input type="submit" class = "btn" name="changepw" value="Submit">
      <span class = "error"> <?php echo $pwErr;?></span><br>
    </form>

    <br>

<!-- (Future) ADD PROVISIONS FOR SHELTERS/CENTERS/CHARITIES TO UPDATE THEIR BUSINESS DETAILS (Update Address, Name, etc.)-->


  </div>

  <footer>
      <p>
          Shelter_db &copy; <?php echo date("Y"); ?>
      </p>
  </footer>

</body>
</html>